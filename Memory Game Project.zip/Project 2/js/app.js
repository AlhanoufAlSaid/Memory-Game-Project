/*
 * Create a list that holds all of your cards
 */
 const cards = ['fa-diamond', 'fa-diamond',
 'fa-paper-plane-o', 'fa-paper-plane-o',
 'fa-anchor', 'fa-anchor',
 'fa-bolt', 'fa-bolt',
 'fa-cube', 'fa-cube',
 'fa-leaf', 'fa-leaf',
 'fa-bicycle', 'fa-bicycle',
 'fa-bomb', 'fa-bomb',
 ];

/*
 * Display the cards on the page
 *   - shuffle the list of cards using the provided "shuffle" method below
 *   - loop through each card and create its HTML
 *   - add each card's HTML to the page
 */

// Shuffle function from http://stackoverflow.com/a/2450976
function shuffle(array) {
	var currentIndex = array.length, temporaryValue, randomIndex;

	while (currentIndex !== 0) {
		randomIndex = Math.floor(Math.random() * currentIndex);
		currentIndex -= 1;
		temporaryValue = array[currentIndex];
		array[currentIndex] = array[randomIndex];
		array[randomIndex] = temporaryValue;
	}
	return array;
}

/*
 * set up the event listener for a card. If a card is clicked:
 *  - display the card's symbol (put this functionality in another function that you call from this one)
 *  - add the card to a *list* of "open" cards (put this functionality in another function that you call from this one)
 *  - if the list already has another card, check to see if the two cards match
 *    + if the cards do match, lock the cards in the open position (put this functionality in another function that you call from this one)
 *    + if the cards do not match, remove the cards from the list and hide the card's symbol (put this functionality in another function that you call from this one)
 *    + increment the move counter and display it on the page (put this functionality in another function that you call from this one)
 *    + if all cards have matched, display a message with the final score (put this functionality in another function that you call from this one)
 */

	window.onload = function() {
		let shuffleTheCards = shuffle(cards);
		    openedCards	  = [];
			currentCard   = [];
			previouseCard = 0;
            matchedCards  = [];
			moveCounter = 0;
			countMoves = document.getElementById('moves');
			restart = document.getElementsByClassName ('restart');
			modal = document.getElementById('modal');
			span = document.getElementsByClassName('close')[0];

		//  restart the game
			restart[0].addEventListener('click', function (){
				location.reload();
			})

		// initialising popup 
		function popup() {
	    				modal.style.display = "flex";
	    				document.getElementById('Msg').innerHTML = 'You did it in '+moveCounter+' moves'+' and '+seconds+' seconds.';
		}

		// Stopwatch initialisation
		let stopWatch = document.getElementById('timer');
			time = 0;
			seconds=0
		
		// start time
		function startTime() {
			time = setInterval(function(){
				seconds++;
				stopWatch.innerHTML = seconds + ' s';
			}, 1000); 
		}

		// stop time 
		function stopTime()	{
			clearInterval(time);
		}
		
		let displayCards = document.getElementsByClassName('card');       
			console.log (displayCards);
		let	clickFlag = true;

		// Click Event
		function cardClick() {
			if (!clickFlag) {
				return;
			}
	 		currentCard = this;
	 		currentCard.removeEventListener('click', cardClick); 
	 		console.log(currentCard);	

	 		// updating counts of the move
	 		moveCounter++ ;
	 		countMoves.innerHTML= moveCounter;
	 		console.log(countMoves);

	 		// ranking;
	 		if ( moveCounter === 20) {
	 			let removeStar = document.getElementById('star3');
				removeStar.style.display = 'none';
	 		} else if (moveCounter ===30) {
	 			let removeStarTwo = document.getElementById('star2');
	 			removeStarTwo.style.display = 'none';
	 			}	

	 		// start stopwatch
	 		if ( moveCounter ===1) {
	 			startTime();
	 		}	
	 			currentCard.classList.add('open', 'show');

	 			if (previouseCard) {
	 				clickFlag = false;

	 				// matching cards
	 				if (currentCard.innerHTML === previouseCard.innerHTML) {
	 					currentCard.classList.add('match');
	 					previouseCard.classList.add('match');
	 					matchedCards.push(currentCard,previouseCard);
	 			 		previouseCard = null ;
	 					
	 					// check if the user won the game
	 					if (cards.length === matchedCards.length) {
	 						stopTime();
	 						popup ();
	 					}
	 					clickFlag = true;

	 				} else {
	 					// when not matched
	 					setTimeout(function(){
	 						previouseCard.classList.remove('open', 'show');
	 						currentCard.classList.remove('open', 'show');	
	 						currentCard.addEventListener('click', cardClick);
	 						previouseCard.addEventListener('click', cardClick);
	 						previouseCard = null ;
	 						clickFlag = true;	 						
	 					}, 500);
	 				}
	 			
	 			} else {
	 					previouseCard = currentCard ;	
	 					openedCards.push(this);	
	 					clickFlag = true;
	 				}					
	 	}  		
	 		// event listener function 
	 	for (i=0 ; i < displayCards.length ; i++) {
			displayCards[i].addEventListener('click', cardClick);
		}		
	 }